# Konar Stock – Godown Stock App

T.R.M.V Konar Rice Shop: head office bill → dealer loading → daily stock report.

## One-time setup
1. Create a GitHub repo named **konar-stock** and push this whole folder.
   (Different repo name/username? Change `server.url` in `capacitor.config.json`.)
2. Repo → **Settings → Pages → Source: GitHub Actions**.
3. **Actions → "Deploy app & build APK" → Run workflow**.
4. When it finishes, download **Artifacts → KonarStock-APK** and install it on the phone.
   First launch needs internet; after that it works offline.

## Releasing an update (no new APK needed)
1. In `www/index.html` change `const APP_VERSION='1.1.0'` (e.g. to `1.1.1`) and push.
2. GitHub Actions deploys automatically.
3. On the phone: ⚙️ Settings → **🔄 Check**, or tap the "New update" banner. Data is kept.
   Rebuild the APK only when changing the app icon, name or server URL.

## Data safety
- Data lives inside the app on the phone. It survives app updates, but NOT "Clear data" or uninstall.
- The installed app auto-saves a backup every day (and on every day submit) to
  **Documents/KonarStock/** (`konar-stock-latest.json` + one file per day).
- New/replacement phone: install the APK → ⚙️ → ⬆️ Restore → pick `konar-stock-latest.json`.
- Also copy that file to Google Drive / WhatsApp yourself once a week (⚙️ → ⬇️ Backup shares it).

## How to use
- **Stock** → 📋 Count: enter opening stock first. 🚚 IN: bags received from lorry. ＋ New: new product.
- **Bills** → ＋ New bill: head office bill (invoice no, dealer, bags).
- **Loading ⚡**: all pending dealers on one screen. Tap **+1** per bag, **−** or UNDO to correct.
- **Report**: Open / In / Out / Close per product, dealer-wise. End of day → **✅ Submit** → WhatsApp (image or text).
- ⚙️: change logo, head office WhatsApp number, Backup / Restore.
