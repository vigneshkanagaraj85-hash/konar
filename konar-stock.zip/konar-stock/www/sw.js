// Konar Stock service worker – network-first (always latest when online), cache fallback when offline
const C='konar-stock-v1';
const SHELL=['./','./index.html','./manifest.json','./logo.png','./icons/icon-192.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request;
  if(r.method!=='GET'||new URL(r.url).origin!==location.origin||r.url.includes('version.json'))return;
  e.respondWith((async()=>{
    const cache=await caches.open(C);
    const net=fetch(r).then(res=>{if(res&&res.ok)cache.put(r,res.clone());return res;});
    const cached=await cache.match(r,{ignoreSearch:true});
    if(cached)return Promise.race([net.catch(()=>cached),new Promise(ok=>setTimeout(()=>ok(cached),3000))]);
    return net.catch(async()=>(await cache.match('./index.html'))||Response.error());
  })());
});
